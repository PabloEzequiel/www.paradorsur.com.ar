<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/losmellizos.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Las Grutas Hoy!</title>
<!-- InstanceEndEditable -->
<!-- InstanceBeginEditable name="head" -->
<style type="text/css">
<!--
.Estilo5 {font-size: 8pt}
-->
</style>
<style type="text/css">
<!--
.Estilo6 {font-size: 8pt}
.Estilo6 {font-size: 11px}
-->
</style>
<style type="text/css">
<!--
.Estilo7 {font-size: 8pt}
.Estilo7 {font-size: 11px}
-->
</style>
<!-- InstanceEndEditable -->
<style type="text/css">
<!--
body {
	background-color: #EEEEEE;
}
.Estilo1 {font-family: Arial, Helvetica, sans-serif}
-->
</style>

<link href="mellizos/images/estilos.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.Estilo2 {color: #FF0000}
.Estilo4 {
	color: #003300;
	font-weight: bold;
}
.Estilo5 {font-size: 11px}
-->
</style>
</head>

<body>
<table width="760" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="3"><img src="images/head.gif" alt="Parador Sur - Las Grutas" width="760" height="130" border="0" usemap="#Map" /></td>
  </tr>
  <tr>
    <td width="24%" id="tdLeft" >	<span class="Estilo5">
	<SCRIPT LANGUAGE="JavaScript1.2">
<!-- Begin
var months=new Array(13);
months[1]="Enero";
months[2]="Febrero";
months[3]="Marzo";
months[4]="Abril";
months[5]="Mayo";
months[6]="Junio";
months[7]="Julio";
months[8]="Augosto";
months[9]="Septiembre";
months[10]="Octubre";
months[11]="Noviembre";
months[12]="Dciembre";
var time=new Date();
var lmonth=months[time.getMonth() + 1];
var date=time.getDate();
var year=time.getYear();
if (year < 2000)    
year = year + 1900;
document.write("<center>" + date + " de " + lmonth + " de " + year + "</center>");
// End -->
</SCRIPT>
</span></td>
    <td width="3%" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="73%" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td height="346" valign="top"  id="tdLeft">
<br/><!-- #BeginLibraryItem "/Library/MellizosLeft.lbi" -->


<link href="images/estilos.css" rel="stylesheet" type="text/css">

	<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
.style2 {color: #003399}
-->
    </style>
	<table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr>
          <td id="menuLeft" width="24%" valign="top">
		  
<table id="navigation" width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="24" align="center" bgcolor="#0099FF"><strong>Secciones</strong></td>
  </tr>
  <tr>
    <td><a href="index.html" class="Estilo1">Inicio</a></td>
  </tr>
   <tr>
    <td><a href="fotos_lasgrutas.html" class="Estilo1">Fotos</a></td>
  </tr>   
  <tr>
    <td> 
    
    
    
    
    
 <table id="navigation2" width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><a href="fotos.html" class="Estilo1">Departamentos</a></td>
  </tr>  
  <tr>
    <td><a href="fotos_lasgrutas_laplaya.html" class="Estilo1">La Playa</a></td>
  </tr>   
  <tr>
    <td bgcolor="#9999CC"> <a href="fotos_lasgrutas_elcentro.html" class="style2">El Centro</a></td>
  </tr>   
  <tr>
    <td><a href="fotos_lasgrutas_terrazas.html" class="Estilo1">Terrazas al Mar</a></td>
  </tr>
  <tr>
    <td><a href="fotos_lasgrutas_coloradas.html" class="Estilo1">Piedras Coloradas</a></td>
  </tr>
   <tr>
    <td><a href="fotos_historia.html" class="Estilo1">La historia</a></td>
  </tr>  
</table>    </td>
  </tr>
  <tr>
    <td><a href="video.html" class="Estilo1">Video</a></td>
  </tr>   
  <tr>
    <td><a href="mapas.html" class="Estilo1">Ubicación y Mapa</a></td>
  </tr>   
  <tr>
    <td><a href="distancias.html" class="Estilo1">Distancias</a></td>
  </tr>
  <tr>
    <td><a href="contacto.html" class="Estilo1">Contacto</a></td>
  </tr>
</table>		  
		  
		  </td>
		</tr>
	</table>		  


<!-- #EndLibraryItem --><!-- #BeginLibraryItem "/Library/MellizosLogos.lbi" -->
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><p align="center"><img src="images/logos/lasgrutas.gif" alt="las grutas" width="100" height="98"></p>
    <p align="center"><img src="images/logos/sao.gif" alt="sao" width="100" height="117"></p></td>
  </tr>
</table>
<!-- #EndLibraryItem --><p>&nbsp;</p>

<!-- PABLO
<table width="100%"  border="0" align="center">
      <tr>
        <td align="center">
<script type="text/javascript"><!PABLO--
google_ad_client = "pub-4671718819110940";
/* 120x240, creado 9/04/08 */
google_ad_slot = "5872948853";
google_ad_width = 120;
google_ad_height = 240;
//--PABLO>
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>		
		</td>
      </tr>
    </table>
PABLO -->    
	
<p>&nbsp;</p></td>
    <td bgcolor="#FFFFFF">&nbsp;</td>
    <td valign="top" bgcolor="#FFFFFF"><p><span class="Estilo4">Las Grutas Hoy &gt; <a href="index.html">Parador Sur</a></span> <!-- InstanceBeginEditable name="menusite" -->&gt; mapa <!-- InstanceEndEditable --></p>
      <!-- InstanceBeginEditable name="BodyRegion1" -->
      <p>Ubicaci&oacute;n del Complejo <strong>Parador Sur</strong> en Las Grutas: </p>
      <p align="left"><a href="images/planoColor.jpg"><img src="images/planoColor_small.gif" alt="Parador Sur" width="500" height="258" border="1" /></a></p>
      <ul>
        <li>ALGO</li>
      </ul>
      <p class="Estilo5"><span class="Estilo7"><em>Las grutas en Google Maps:</em></span></p>
      
   
   


    
    </td>
  </tr>
  <tr>
    <td id="tdLeft">&nbsp;</td>
    <td bgcolor="#FFFFFF">&nbsp;</td>
    <td bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><!-- #BeginLibraryItem "/Library/MellizosDown.lbi" -->	<style type="text/css">
<!--
.Estilo1 {color: #FFFFFF}
.Estilo2 {
	font-size: 10px;
	font-family: Arial, Helvetica, sans-serif;
}
-->
    </style>
	<table width="100%" border="0" align="right" cellpadding="0" cellspacing="0">
      <tr bgcolor="#0066CC">
        <td align="center"><div id="footer"> 

	<a href="index.html">Inicio</a> | 
    <a href="fotos.html">Fotos</a> | 
    <a href="mapas.html">Mapas</a> | 
    <a href="distancias.html">Distancias</a> | 
    <a href="contacto.html">Contacto</a> 


</div></td>
      </tr>
	  <tr bgcolor="#000000">
		<td height="19" align="center" valign="middle"><div id="footer" class="Estilo1 Estilo2"><a href="http://www.lasgrutashoy.com.ar" target="_top">© Copyright 2006 www.lasgrutashoy.com.ar</a> • Todos los derechos reservados • <a href="http://www.piprod.com.ar" target="piprod">Web: Pi Prod</a> </div></td>
	  </tr>
    </table>

<!-- #EndLibraryItem --></td>
  </tr>
</table>

<map name="Map" id="Map">
  <area shape="rect" coords="11,10,181,104" href="index.html" />
<area shape="rect" coords="191,102,382,127" href="mailto:silvidd@gmail.com?subject=Parador Sur Informacion" />
</map></body>
<!-- InstanceEnd --></html>

<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-4109067-1";
urchinTracker();
</script>	